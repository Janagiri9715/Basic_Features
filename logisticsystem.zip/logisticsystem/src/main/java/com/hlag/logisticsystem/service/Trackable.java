package com.hlag.logisticsystem.service;


public interface Trackable {

	void trackCargo();

	// void aa();
	//
	// void bb();
}
