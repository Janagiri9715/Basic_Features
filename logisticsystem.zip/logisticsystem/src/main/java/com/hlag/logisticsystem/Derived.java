package com.hlag.logisticsystem;


public class Derived extends Base {

	int value1;
	int value2;

	public Derived() {
		super(10, 20);
	}

	// public Derived(int value1, int value2) {
	// super(10, 20);
	// this.value1 = value1;
	// this.value2 = value2;
	// }

	@Override
	public void test() {
		System.out.println("Test Method Called From Derived");
	}

}

