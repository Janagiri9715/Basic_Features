package com.hlag.logisticsystem.dto;

import com.hlag.logisticsystem.Derived;

public class Derived2 extends Derived {

	public Derived2() {
		super();
	}

	public static void main(String[] args) {
		Derived dd = new Derived();
	}

}
