package com.hlag.logisticsystem;

public class Test {

	public static void main(String[] args) {
		// Base dd = new Derived();
		// dd.test();
		// Case 1 :
		// Flyable f = new IronMan();
		// ( new Ironman() object act as Object for Flyable so only interface method (Fly) will
		// show not method in Ironman class )
		// f.fly();
		// Case 2 :
		// Test t = new Test();
		// t.getData();
		// Case 3 :
		testing(new IronMan());
		// ( new Ironman() object act as Object for Flyable so only pass IronMan Object in Parameter instead of Flyable
		// Object )
	}

	static {
		System.out.println("Static Block Executed");
	}

	static void getData() {
		Flyable f = new IronMan();
		f.fly();
	}

	public static void testing(Flyable ff) {
		ff.fly();
	}

}
