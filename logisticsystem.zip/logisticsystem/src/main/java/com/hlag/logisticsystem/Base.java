package com.hlag.logisticsystem;


public class Base {

	int value1;
	int value2;

	public Base() {

	}

	public Base(int value1, int value2) {
		super();
		this.value1 = value1;
		this.value2 = value2;
	}

	public void test() {
		System.out.println("Test Method Called From Base");
	}
}
