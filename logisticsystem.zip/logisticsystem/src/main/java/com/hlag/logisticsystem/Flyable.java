package com.hlag.logisticsystem;


public interface Flyable {

	public void fly();

	// JAVA 8 Features we can use static methods in interface directly

	// public static void fly() {
	// System.out.println("HIIIIIIIIIIIIIIIIIIIIIII");
	// }
	//
	// public static void main(String[] args) {
	// fly();
	// }

}
