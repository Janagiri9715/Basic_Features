package com.hlag.logisticsystem.service;

public class Cargo implements Trackable {

	private static String cargoId;
	private static String description;
	private static int weight;

	public Cargo(String cargoId, String description, int weight) {
		super();
		this.cargoId = cargoId;
		this.description = description;
		this.weight = weight;
	}

	public static void display(double weight) {
		System.out.println(" cargoId :: " + cargoId + " description :: " + description + " weight :: " + weight);
	}

	public double calculateShippingCost(double weight) {
		return weight * 2.5; // Cost per kg
	}

	public double calculateShippingCost(double weight, double distance) {
		return weight * distance * 0.05; // Cost based on distance
	}

	public static void main(String[] args) {

		Cargo cargo = new Cargo("A", "B", 100);

		// cargo.calculateShippingCost(weight);
		cargo.display(cargo.calculateShippingCost(weight));
		cargo.trackCargo();
	}

	@Override
	public void trackCargo() {
		// TODO Auto-generated method stub
		System.out.println("Tracking cargo ID: " + cargoId);

	}


}
