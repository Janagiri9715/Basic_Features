package com.hlag.logisticsystem;


public class IronMan implements Flyable {

	@Override
	public void fly() {
		// TODO Auto-generated method stub
		System.out.println("Inside IronMan Fly");

	}

	public void display() {
		System.out.println("Inside Display");
	}

	public static void main(String[] args) {
		IronMan f = new IronMan();
		// Flyable.fly();
	}

}
