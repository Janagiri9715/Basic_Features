package com.hlag.logisticsystem.service;

import java.util.ArrayList;
import java.util.List;

public class CargoItem {

	double weight;
	String dimention;
	String type;
	private List<String> cargotypes = new ArrayList<>();

	public CargoItem(double weight, String dimention, String type) {
		super();
		this.weight = weight;
		this.dimention = dimention;
		this.type = type;
	}

	public String shippingCost() {
		double cost = 1;
		cost = weight * cost;
		cargotypes.add("Total Cost " + cost);
		return cargotypes.get(cargotypes.size() - 1);
	}

	public static void main(String[] args) {
		CargoItem cargoItem = new CargoItem(10, "", "Goods");

		System.out.println(cargoItem.shippingCost());
	}
}


