package com.hlag.logisticsystem.service;


public class FragileCargo extends Cargo {

	private static String handlingInstructions;

	public FragileCargo(String cargoId, String description, int weight, String handlingInstructions) {
		super(cargoId, description, weight);
		this.handlingInstructions = handlingInstructions;

	}

	// @Override
	public static void display(double weight) {
		// super.display();
		System.out.println("handlingInstructions :: " + handlingInstructions);
	}

	public static void main(String[] args) {

		Cargo cargo1 = new Cargo("C001", "Books", 50);
		Cargo cargo2 = new FragileCargo("C002", "Glassware", 30, "Handle with care.");

		cargo2.display(1);
	}

}
