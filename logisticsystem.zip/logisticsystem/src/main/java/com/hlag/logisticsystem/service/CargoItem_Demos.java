package com.hlag.logisticsystem.service;


public abstract class CargoItem_Demos {

	 protected String cargoId;

	public CargoItem_Demos(String cargoId) {
       this.cargoId = cargoId;
   }

   // Abstract method
   public abstract double calculateShippingCost();
}


