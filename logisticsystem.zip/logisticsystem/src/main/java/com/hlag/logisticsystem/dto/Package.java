package com.hlag.logisticsystem.dto;

import java.time.LocalDate;
import java.util.Collections;
import java.util.List;

import javax.net.ssl.SSLEngineResult.Status;

public class Package {

	private final String trackingId;
	private double weight;
	private String destination;
	private String status;
	private List<String> milestones;

	// public Package(String trackingID, String destination, double weight) {
	// super();
	// this.trackingId = trackingID;//
	// this.destination = destination;
	// this.status = "In Transit"; // Initial status
	// this.milestones = new ArrayList<>();
	// setWeight(weight);
	// }
	//
	// public Package() {
	// this.trackingId = "";
	//
	// }

	private Package() {
		super();
		this.trackingId = "";

	}

	private static Package pack;

	public static Package getInstance() {
		if (pack == null) {
			return new Package();
		}
		return pack;

	}

	public void markasDelivered(Status status) {
		if (this.status.equals(status)) {
			throw new IllegalArgumentException("package is in transist");
		}
		this.status = "delivered";
		this.milestones.add("delivered on " + LocalDate.now());
	}

	public String getTrackingId() {
		return trackingId;
	}

	public double getWeight() {
		return weight;
	}

	public void setWeight(double weight) {
		if (weight <= 0) {
			throw new IllegalArgumentException("Weight must be positive");
		}
		this.weight = weight;
	}

	public String getDestination() {
		return destination;
	}

	public void setDestination(String destination) {
		this.destination = destination;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public List<String> getMilestones() {
		return Collections.unmodifiableList(milestones);
	}

	public void setMilestones(List<String> milestones) {
		this.milestones = milestones;
	}

}
